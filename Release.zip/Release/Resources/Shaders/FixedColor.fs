#version 460 core

out vec4 FinalColor;

void main()
{
    FinalColor = vec4(1.0f, 1.0f, 1.0f, 1.0f);
}